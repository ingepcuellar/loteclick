<?php
/**
 * LoteClick API - Health Check
 */
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');

$result = ['status' => 'ok', 'php' => phpversion(), 'timestamp' => date('c')];

// Test database connection
try {
    require_once __DIR__ . '/config.php';
    $pdo = getConnection();
    $stmt = $pdo->query("SELECT 1");
    $result['database'] = 'connected';

    // Check tables exist
    $stmt = $pdo->query("SHOW TABLES");
    $tables = $stmt->fetchAll(PDO::FETCH_COLUMN);
    $result['tables'] = $tables;
    $result['tables_count'] = count($tables);
} catch (Exception $e) {
    $result['database'] = 'error';
    $result['db_error'] = $e->getMessage();
}

echo json_encode($result, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
