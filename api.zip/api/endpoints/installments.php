<?php
/**
 * LoteClick API - Installments Endpoints
 */
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../jwt.php';

$auth = requireAuth();
$action = getParam('action', '');
$method = getMethod();

switch ($action) {
    case 'bySale':
        getInstallmentsBySale();
        break;
    case 'generate':
        generateInstallments();
        break;
    case 'markAsPaid':
        markAsPaid();
        break;
    case 'markAsPartial':
        markAsPartial();
        break;
    case 'recalculate':
        recalculateInstallments();
        break;
    case 'restructure':
        restructureInstallments();
        break;
    case 'deleteBySale':
        deleteBySale();
        break;
    default:
        // Standard CRUD
        switch ($method) {
            case 'GET':
                $id = getParam('id');
                $id ? getInstallment($id) : getAllInstallments();
                break;
            case 'PUT':
            case 'PATCH':
                $id = getParam('id');
                if (!$id) jsonError('ID requerido');
                updateInstallment($id);
                break;
            case 'DELETE':
                $id = getParam('id');
                if (!$id) jsonError('ID requerido');
                deleteInstallment($id);
                break;
            default:
                jsonError('Acción no válida', 400);
        }
}

function getAllInstallments() {
    $pdo = getConnection();
    $stmt = $pdo->query("SELECT * FROM installments ORDER BY due_date ASC");
    jsonResponse(['data' => $stmt->fetchAll()]);
}

function getInstallment($id) {
    $pdo = getConnection();
    $stmt = $pdo->prepare("SELECT * FROM installments WHERE id = ?");
    $stmt->execute([$id]);
    $inst = $stmt->fetch();
    if (!$inst) jsonError('Cuota no encontrada', 404);
    jsonResponse(['data' => $inst]);
}

function getInstallmentsBySale() {
    $pdo = getConnection();
    $saleId = getParam('saleId');
    if (!$saleId) jsonError('saleId requerido');

    $stmt = $pdo->prepare("SELECT * FROM installments WHERE sale_id = ? ORDER BY installment_number ASC");
    $stmt->execute([$saleId]);
    jsonResponse(['data' => $stmt->fetchAll()]);
}

function generateInstallments() {
    if (getMethod() !== 'POST') jsonError('Método no permitido', 405);

    $body = getJsonBody();
    $saleId = $body['saleId'] ?? $body['sale_id'] ?? null;
    $totalAmount = floatval($body['totalAmount'] ?? 0);
    $numInstallments = intval($body['numInstallments'] ?? 0);
    $startDate = $body['startDate'] ?? date('Y-m-d');
    $downPayment = floatval($body['downPayment'] ?? 0);

    if (!$saleId || $numInstallments <= 0) {
        jsonError('saleId y numInstallments son requeridos');
    }

    $pdo = getConnection();

    // Delete existing installments for this sale
    $pdo->prepare("DELETE FROM installments WHERE sale_id = ?")->execute([$saleId]);

    $installmentAmount = round($totalAmount / $numInstallments, 2);
    $installments = [];

    $pdo->beginTransaction();
    try {
        $stmt = $pdo->prepare(
            "INSERT INTO installments (id, sale_id, installment_number, amount, due_date, status, paid_amount) 
             VALUES (?, ?, ?, ?, ?, 'pending', 0)"
        );

        for ($i = 1; $i <= $numInstallments; $i++) {
            $dueDate = date('Y-m-d', strtotime("$startDate +$i months"));

            // Last installment gets the remainder to avoid rounding issues
            $amount = ($i === $numInstallments)
                ? round($totalAmount - ($installmentAmount * ($numInstallments - 1)), 2)
                : $installmentAmount;

            $instId = generateUUID();
            $stmt->execute([$instId, $saleId, $i, $amount, $dueDate]);

            $installments[] = [
                'id' => $instId,
                'sale_id' => $saleId,
                'installment_number' => $i,
                'amount' => $amount,
                'due_date' => $dueDate,
                'status' => 'pending',
                'paid_amount' => 0
            ];
        }

        $pdo->commit();
        jsonResponse(['data' => $installments], 201);
    } catch (Exception $e) {
        $pdo->rollBack();
        jsonError('Error al generar cuotas: ' . $e->getMessage(), 500);
    }
}

function markAsPaid() {
    if (getMethod() !== 'POST' && getMethod() !== 'PATCH') jsonError('Método no permitido', 405);

    $body = getJsonBody();
    $id = $body['id'] ?? getParam('id');
    $paymentId = $body['paymentId'] ?? $body['payment_id'] ?? null;

    if (!$id) jsonError('ID requerido');

    $pdo = getConnection();
    $stmt = $pdo->prepare(
        "UPDATE installments SET status = 'paid', paid_amount = amount, paid_date = CURDATE(), payment_id = ? WHERE id = ?"
    );
    $stmt->execute([$paymentId, $id]);

    $stmt = $pdo->prepare("SELECT * FROM installments WHERE id = ?");
    $stmt->execute([$id]);
    jsonResponse(['data' => $stmt->fetch()]);
}

function markAsPartial() {
    if (getMethod() !== 'POST' && getMethod() !== 'PATCH') jsonError('Método no permitido', 405);

    $body = getJsonBody();
    $id = $body['id'] ?? getParam('id');
    $paidAmount = floatval($body['paidAmount'] ?? $body['paid_amount'] ?? 0);

    if (!$id) jsonError('ID requerido');

    $pdo = getConnection();
    $stmt = $pdo->prepare(
        "UPDATE installments SET status = 'partial', paid_amount = ?, paid_date = CURDATE() WHERE id = ?"
    );
    $stmt->execute([$paidAmount, $id]);

    $stmt = $pdo->prepare("SELECT * FROM installments WHERE id = ?");
    $stmt->execute([$id]);
    jsonResponse(['data' => $stmt->fetch()]);
}

function recalculateInstallments() {
    if (getMethod() !== 'POST') jsonError('Método no permitido', 405);

    $body = getJsonBody();
    $saleId = $body['saleId'] ?? $body['sale_id'];
    if (!$saleId) jsonError('saleId requerido');

    $pdo = getConnection();

    // Get total paid
    $stmt = $pdo->prepare("SELECT COALESCE(SUM(amount), 0) as total FROM payments WHERE sale_id = ?");
    $stmt->execute([$saleId]);
    $totalPaid = floatval($stmt->fetch()['total']);

    // Get sale total
    $stmt = $pdo->prepare("SELECT sale_price, down_payment FROM sales WHERE id = ?");
    $stmt->execute([$saleId]);
    $sale = $stmt->fetch();
    if (!$sale) jsonError('Venta no encontrada', 404);

    $remaining = floatval($sale['sale_price']) - $totalPaid;

    // Get pending installments
    $stmt = $pdo->prepare("SELECT * FROM installments WHERE sale_id = ? AND status IN ('pending', 'partial') ORDER BY installment_number ASC");
    $stmt->execute([$saleId]);
    $pendingInstallments = $stmt->fetchAll();

    if (empty($pendingInstallments) || $remaining <= 0) {
        jsonResponse(['data' => []]);
        return;
    }

    $newAmount = round($remaining / count($pendingInstallments), 2);
    $updated = [];

    $pdo->beginTransaction();
    try {
        $stmtUpdate = $pdo->prepare("UPDATE installments SET amount = ?, paid_amount = 0, status = 'pending' WHERE id = ?");

        foreach ($pendingInstallments as $i => $inst) {
            $amount = ($i === count($pendingInstallments) - 1)
                ? round($remaining - ($newAmount * (count($pendingInstallments) - 1)), 2)
                : $newAmount;

            $stmtUpdate->execute([$amount, $inst['id']]);
            $inst['amount'] = $amount;
            $inst['status'] = 'pending';
            $inst['paid_amount'] = 0;
            $updated[] = $inst;
        }

        $pdo->commit();
        jsonResponse(['data' => $updated]);
    } catch (Exception $e) {
        $pdo->rollBack();
        jsonError('Error al recalcular cuotas: ' . $e->getMessage(), 500);
    }
}

function restructureInstallments() {
    if (getMethod() !== 'POST') jsonError('Método no permitido', 405);

    $body = getJsonBody();
    $saleId = $body['saleId'] ?? $body['sale_id'];
    $newNumInstallments = intval($body['newNumInstallments'] ?? 0);
    $startDate = $body['startDate'] ?? date('Y-m-d');

    if (!$saleId || $newNumInstallments <= 0) {
        jsonError('saleId y newNumInstallments son requeridos');
    }

    $pdo = getConnection();

    // Get remaining balance
    $stmt = $pdo->prepare("SELECT COALESCE(SUM(amount), 0) as total FROM payments WHERE sale_id = ?");
    $stmt->execute([$saleId]);
    $totalPaid = floatval($stmt->fetch()['total']);

    $stmt = $pdo->prepare("SELECT sale_price FROM sales WHERE id = ?");
    $stmt->execute([$saleId]);
    $sale = $stmt->fetch();
    if (!$sale) jsonError('Venta no encontrada', 404);

    $remaining = floatval($sale['sale_price']) - $totalPaid;

    // Delete all pending installments
    $pdo->prepare("DELETE FROM installments WHERE sale_id = ? AND status IN ('pending', 'partial', 'overdue')")->execute([$saleId]);

    // Get max installment number
    $stmt = $pdo->prepare("SELECT COALESCE(MAX(installment_number), 0) as maxNum FROM installments WHERE sale_id = ?");
    $stmt->execute([$saleId]);
    $startNum = intval($stmt->fetch()['maxNum']) + 1;

    $installmentAmount = round($remaining / $newNumInstallments, 2);
    $installments = [];

    $pdo->beginTransaction();
    try {
        $stmtInsert = $pdo->prepare(
            "INSERT INTO installments (id, sale_id, installment_number, amount, due_date, status, paid_amount) 
             VALUES (?, ?, ?, ?, ?, 'pending', 0)"
        );

        for ($i = 0; $i < $newNumInstallments; $i++) {
            $num = $startNum + $i;
            $dueDate = date('Y-m-d', strtotime("$startDate +" . ($i + 1) . " months"));
            $amount = ($i === $newNumInstallments - 1)
                ? round($remaining - ($installmentAmount * ($newNumInstallments - 1)), 2)
                : $installmentAmount;

            $instId = generateUUID();
            $stmtInsert->execute([$instId, $saleId, $num, $amount, $dueDate]);

            $installments[] = [
                'id' => $instId,
                'sale_id' => $saleId,
                'installment_number' => $num,
                'amount' => $amount,
                'due_date' => $dueDate,
                'status' => 'pending',
                'paid_amount' => 0
            ];
        }

        $pdo->commit();
        jsonResponse(['data' => $installments], 201);
    } catch (Exception $e) {
        $pdo->rollBack();
        jsonError('Error al reestructurar cuotas: ' . $e->getMessage(), 500);
    }
}

function updateInstallment($id) {
    $pdo = getConnection();
    $body = getJsonBody();

    $fields = [];
    $params = [];

    if (isset($body['amount'])) { $fields[] = 'amount = ?'; $params[] = floatval($body['amount']); }
    if (isset($body['due_date'])) { $fields[] = 'due_date = ?'; $params[] = $body['due_date']; }
    if (isset($body['dueDate'])) { $fields[] = 'due_date = ?'; $params[] = $body['dueDate']; }
    if (isset($body['status'])) { $fields[] = 'status = ?'; $params[] = $body['status']; }
    if (isset($body['paid_amount'])) { $fields[] = 'paid_amount = ?'; $params[] = floatval($body['paid_amount']); }
    if (isset($body['paidAmount'])) { $fields[] = 'paid_amount = ?'; $params[] = floatval($body['paidAmount']); }
    if (isset($body['paid_date'])) { $fields[] = 'paid_date = ?'; $params[] = $body['paid_date']; }
    if (isset($body['payment_id'])) { $fields[] = 'payment_id = ?'; $params[] = $body['payment_id']; }

    if (empty($fields)) jsonError('No hay campos para actualizar');

    $params[] = $id;
    $pdo->prepare("UPDATE installments SET " . implode(', ', $fields) . " WHERE id = ?")->execute($params);

    $stmt = $pdo->prepare("SELECT * FROM installments WHERE id = ?");
    $stmt->execute([$id]);
    jsonResponse(['data' => $stmt->fetch()]);
}

function deleteInstallment($id) {
    $pdo = getConnection();
    $pdo->prepare("DELETE FROM installments WHERE id = ?")->execute([$id]);
    jsonResponse(['data' => ['id' => $id, 'deleted' => true]]);
}

function deleteBySale() {
    if (getMethod() !== 'DELETE' && getMethod() !== 'POST') jsonError('Método no permitido', 405);

    $saleId = getParam('saleId') ?? (getJsonBody()['saleId'] ?? null);
    if (!$saleId) jsonError('saleId requerido');

    $pdo = getConnection();
    $pdo->prepare("DELETE FROM installments WHERE sale_id = ?")->execute([$saleId]);
    jsonResponse(['data' => ['sale_id' => $saleId, 'deleted' => true]]);
}
