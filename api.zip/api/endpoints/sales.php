<?php
/**
 * LoteClick API - Sales Endpoints
 */
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../jwt.php';

$auth = requireAuth();
$action = getParam('action', '');
$method = getMethod();

if ($action === 'byProject') {
    getSalesByProject();
    exit;
}

switch ($method) {
    case 'GET':
        $id = getParam('id');
        $id ? getSale($id) : getAllSales();
        break;
    case 'POST':
        createSale();
        break;
    case 'PUT':
    case 'PATCH':
        $id = getParam('id');
        if (!$id) jsonError('ID requerido');
        updateSale($id);
        break;
    case 'DELETE':
        $id = getParam('id');
        if (!$id) jsonError('ID requerido');
        deleteSale($id);
        break;
    default:
        jsonError('Método no permitido', 405);
}

function enrichSale($pdo, $sale) {
    // Get project info
    $stmt = $pdo->prepare("SELECT id, name, location FROM projects WHERE id = ?");
    $stmt->execute([$sale['project_id']]);
    $sale['project'] = $stmt->fetch() ?: null;

    // Get lot info
    $stmt = $pdo->prepare("SELECT id, number, area, price FROM lots WHERE id = ?");
    $stmt->execute([$sale['lot_id']]);
    $sale['lot'] = $stmt->fetch() ?: null;

    // Get client info
    $stmt = $pdo->prepare("SELECT id, name, document, phone, email, address FROM clients WHERE id = ?");
    $stmt->execute([$sale['client_id']]);
    $sale['client'] = $stmt->fetch() ?: null;

    // Get payments
    $stmt = $pdo->prepare("SELECT * FROM payments WHERE sale_id = ? ORDER BY payment_date DESC");
    $stmt->execute([$sale['id']]);
    $sale['payments'] = $stmt->fetchAll();

    return $sale;
}

function getAllSales() {
    $pdo = getConnection();
    $stmt = $pdo->query("SELECT * FROM sales ORDER BY created_at DESC");
    $sales = $stmt->fetchAll();

    foreach ($sales as &$s) {
        $s = enrichSale($pdo, $s);
    }

    jsonResponse(['data' => $sales]);
}

function getSale($id) {
    $pdo = getConnection();
    $stmt = $pdo->prepare("SELECT * FROM sales WHERE id = ?");
    $stmt->execute([$id]);
    $sale = $stmt->fetch();
    if (!$sale) jsonError('Venta no encontrada', 404);

    $sale = enrichSale($pdo, $sale);
    jsonResponse(['data' => $sale]);
}

function getSalesByProject() {
    $pdo = getConnection();
    $projectId = getParam('projectId');
    if (!$projectId) jsonError('projectId requerido');

    $stmt = $pdo->prepare("SELECT * FROM sales WHERE project_id = ? ORDER BY sale_date DESC");
    $stmt->execute([$projectId]);
    $sales = $stmt->fetchAll();

    foreach ($sales as &$s) {
        $s = enrichSale($pdo, $s);
    }

    jsonResponse(['data' => $sales]);
}

function createSale() {
    $pdo = getConnection();
    $body = getJsonBody();
    $id = generateUUID();

    $pdo->beginTransaction();
    try {
        $stmt = $pdo->prepare(
            "INSERT INTO sales (id, project_id, lot_id, client_id, sale_price, sale_date, payment_type, down_payment, installments, notes) 
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
        );

        $paymentType = $body['payment_type'] ?? $body['paymentType'] ?? 'cash';
        if ($paymentType === 'installments') $paymentType = 'credit';

        $stmt->execute([
            $id,
            $body['project_id'] ?? $body['projectId'],
            $body['lot_id'] ?? $body['lotId'],
            $body['client_id'] ?? $body['clientId'],
            floatval($body['sale_price'] ?? $body['totalPrice'] ?? 0),
            $body['sale_date'] ?? $body['saleDate'] ?? date('Y-m-d'),
            $paymentType,
            floatval($body['down_payment'] ?? $body['downPayment'] ?? 0),
            intval($body['installments'] ?? $body['numberOfInstallments'] ?? 1),
            $body['notes'] ?? null
        ]);

        // Mark lot as sold
        $lotId = $body['lot_id'] ?? $body['lotId'];
        $pdo->prepare("UPDATE lots SET status = 'sold' WHERE id = ?")->execute([$lotId]);

        $pdo->commit();

        $stmt = $pdo->prepare("SELECT * FROM sales WHERE id = ?");
        $stmt->execute([$id]);
        jsonResponse(['data' => $stmt->fetch()], 201);

    } catch (Exception $e) {
        $pdo->rollBack();
        jsonError('Error al crear venta: ' . $e->getMessage(), 500);
    }
}

function updateSale($id) {
    $pdo = getConnection();
    $body = getJsonBody();

    $paymentType = $body['payment_type'] ?? $body['paymentType'] ?? 'cash';
    if ($paymentType === 'installments') $paymentType = 'credit';

    $stmt = $pdo->prepare(
        "UPDATE sales SET project_id = ?, lot_id = ?, client_id = ?, sale_price = ?, sale_date = ?, 
         payment_type = ?, down_payment = ?, installments = ?, notes = ? WHERE id = ?"
    );
    $stmt->execute([
        $body['project_id'] ?? $body['projectId'],
        $body['lot_id'] ?? $body['lotId'],
        $body['client_id'] ?? $body['clientId'],
        floatval($body['sale_price'] ?? $body['totalPrice'] ?? 0),
        $body['sale_date'] ?? $body['saleDate'],
        $paymentType,
        floatval($body['down_payment'] ?? $body['downPayment'] ?? 0),
        intval($body['installments'] ?? 1),
        $body['notes'] ?? null,
        $id
    ]);

    $stmt = $pdo->prepare("SELECT * FROM sales WHERE id = ?");
    $stmt->execute([$id]);
    jsonResponse(['data' => $stmt->fetch()]);
}

function deleteSale($id) {
    $pdo = getConnection();

    // Get lot_id before deleting to mark it as available
    $stmt = $pdo->prepare("SELECT lot_id FROM sales WHERE id = ?");
    $stmt->execute([$id]);
    $sale = $stmt->fetch();

    if ($sale) {
        $pdo->prepare("UPDATE lots SET status = 'available' WHERE id = ?")->execute([$sale['lot_id']]);
    }

    $pdo->prepare("DELETE FROM sales WHERE id = ?")->execute([$id]);
    jsonResponse(['data' => ['id' => $id, 'deleted' => true]]);
}
